//
//  CustomCell.h
//  iTravel
//
//  Created by Student05 on 2/7/13.
//  Copyright (c) 2013 Student05. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomCell : UITableViewCell

@property (nonatomic, weak) IBOutlet UILabel *nameLabel;
@property (nonatomic, weak) IBOutlet UILabel *addressLabel;
@property (nonatomic, weak) IBOutlet UIImageView *placeImageView;

@end
