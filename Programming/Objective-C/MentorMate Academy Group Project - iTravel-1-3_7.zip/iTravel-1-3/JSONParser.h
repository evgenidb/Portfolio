//
//  JSONParser.h
//  iTravel
//
//  Created by Student08 on 2/8/13.
//  Copyright (c) 2013 Student05. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JSONParser : NSObject


// Main Parsers
- (NSArray *) getGoogleNearbyLocationsJSONWithOptionsDict:(NSDictionary*)optionsDict;
- (NSArray *) getGoogleGeocodingJSONWithLocationCoordinates:(NSDictionary*)optionsDict;


// Methods for testing
-(BOOL) testParseGoogleNearbyLocationsJSONWithOptionsDict;

@end
