//
//  GameViewController.m
//  iTravel
//
//  Created by Student05 on 2/4/13.
//  Copyright (c) 2013 Student05. All rights reserved.
//

#import "GameViewController.h"
#import "Country.h"
#import "CountryBook.h"


@interface GameViewController ()
@property (nonatomic,strong) Country *question;

@end

@implementation GameViewController
@synthesize question=_question;
@synthesize score=_score;


@synthesize countryContinent=_countryContinent;
@synthesize countryImage=_countryImage;
@synthesize hintLabel=_hintLabel;
@synthesize wrongAnswerLabel=_wrongAnswerLabel;
@synthesize countrysFlag=_countrysFlag;
@synthesize countrysLocation=_countrysLocation;
@synthesize scoreLabel = _scoreLabel;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.question = [[CountryBook sharedInstance] countryatRandomIndex];
    self.title=self.question.name;
    switch (self.question.continent) {
        case 0:
            self.countryContinent.text=@"this country is in Antarctica";
            break;
        case 1:
            self.countryContinent.text=@"this country is in Australia";
            break;
        case 2:
            self.countryContinent.text=@"this country is in Africa";
            break;
        case 3:
            self.countryContinent.text=@"this country is in Asia";
            break;
        case 4:
            self.countryContinent.text=@"this country is in Europe";
            break;
        case 5:
            self.countryContinent.text=@"this country is in South America";
            break;
        case 6:
            self.countryContinent.text=@"this country is in North America";
            break;
    }
    self.countryImage.image = [UIImage imageNamed:self.question.borders];
    self.countrysFlag.image = [UIImage imageNamed:self.question.flag];
    self.countrysLocation.image = [UIImage imageNamed:self.question.location];
    self.answerTextField.text=@"";
    self.wrongAnswerLabel.text=@"";
    self.hintLabel.text=@"use hint";
    
    
    int storedValue = [[NSUserDefaults standardUserDefaults] integerForKey:@"SCORE"];
    if (storedValue != 0) {
        [self.scoreLabel setText:[NSString stringWithFormat:@"%d", storedValue]];
        self.score = storedValue;
    }
    
    
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardDidShow:) name:UIKeyboardDidShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardDidHide:) name:UIKeyboardDidHideNotification object:nil];
}

-(void)keyboardDidShow:(NSNotification *)notification{
    if ([[UIScreen mainScreen] bounds].size.height == 568) {
        [self.view setFrame:CGRectMake(0, -100, 320, 568)]; //if iphone 5
    } else {
        [self.view setFrame:CGRectMake(0, -100, 320, 504)]; //if iphone 3g 4 4s
    }
}
-(void)keyboardDidHide:(NSNotification *)notification{
    if ([[UIScreen mainScreen] bounds].size.height == 568) {
        [self.view setFrame:CGRectMake(0, 0, 320, 568)]; //if iphone 5
    } else {
        [self.view setFrame:CGRectMake(0, 0, 320, 504)]; //if iphone 3g 4 4s
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)useHintButton:(id)sender {
    int len = [self.question.capital length];
    NSString *inBetweem = @"-";
    for (int i = 0; i<(len-3); i++) {
        inBetweem = [[NSString alloc] initWithFormat:@"%@ -",inBetweem];
    }
    NSString *hint = [[NSString alloc] initWithFormat:@"%c %@ %c",[self.question.capital characterAtIndex:0],
                      inBetweem,
                      [self.question.capital characterAtIndex:len-1]];
    self.hintLabel.text=hint;
    
}

- (IBAction)answerButton:(id)sender {
    if([self.answerTextField.text isEqualToString:self.question.capital])
    {
        int i=0;
        while (![self.question.name isEqualToString:[[CountryBook sharedInstance] countryAtIndex:i].name]) {
            i++;
        }
        NSLog(@"%d",i);
        [[CountryBook sharedInstance] countryAtIndex:i].isAnswered=YES;
        
        self.score++;
        [self.scoreLabel setText:[NSString stringWithFormat:@"%d", self.score]];
        
        [[NSUserDefaults standardUserDefaults] setInteger:self.score forKey:@"SCORE"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
        UIAlertView *message = [[UIAlertView alloc] initWithTitle:@"Correct"
                                                          message:@"the capital is correct"
                                                         delegate:self
                                                cancelButtonTitle:@"Next"
                                                otherButtonTitles:nil];
        
        [message show];
        
    }
    else{
        UIAlertView *message = [[UIAlertView alloc] initWithTitle:@"Incorrect"
                                                          message:@"this is not the capital of the country"
                                                         delegate:self
                                                cancelButtonTitle:@"OK"
                                                otherButtonTitles: nil];
        [message show];
        self.wrongAnswerLabel.text=@"WRONG ANSWER";
        //number of hints --
        
    }
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    NSString *title = [alertView buttonTitleAtIndex:buttonIndex];
    if([title isEqualToString:@"Next"]){
        [self viewDidLoad];
        [self.answerTextField resignFirstResponder];
    }
    if([title isEqualToString:@"OK"]){
        self.wrongAnswerLabel.text=@"WRONG ANSWER";
    }
    
}

-(IBAction)backgrondTouched:(id)sender{
    [self.answerTextField resignFirstResponder];
}

-(void)textFieldShouldReturn:(id)sender{
    [sender resignFirstResponder];
}
-(IBAction)textFieldBeganEditing:(id)sender{
    self.wrongAnswerLabel.text=@"";
}


@end
