//
//  ListTableViewController.m
//  iTravel
//
//  Created by Student05 on 2/4/13.
//  Copyright (c) 2013 Student05. All rights reserved.
//

#import "ListTableViewController.h"
#import "DetailInfoVIewControllerViewController.h"
#import "CustomCell.h"

#import "AppDelegate.h"
#import "Place.h"

#import "TemporaryChart.h"

@interface ListTableViewController ()

@end

@implementation ListTableViewController
@synthesize places=_places;
@synthesize placesTableView;
@synthesize resultsController;

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    self.title = @"Visited Places";
    [super viewDidLoad];

    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
 
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;

    
    [self.navigationItem setRightBarButtonItem:self.editButtonItem];
    
    AppDelegate* delegate = (AppDelegate*) [UIApplication sharedApplication].delegate;
	NSManagedObjectContext *moc = [delegate managedObjectContext];
	NSEntityDescription *entityDescription = [NSEntityDescription entityForName:@"Place" inManagedObjectContext:moc];
    NSSortDescriptor *sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:@"name" ascending:YES];
	NSFetchRequest *request = [[NSFetchRequest alloc] init];
	[request setEntity:entityDescription];
    [request setSortDescriptors:[NSArray arrayWithObject:sortDescriptor]];
    
    self.resultsController = [[NSFetchedResultsController alloc] initWithFetchRequest:request managedObjectContext:moc sectionNameKeyPath:nil cacheName:@"object_list.cache"];
    self.resultsController.delegate = self;
    
    NSError* error;
	BOOL success = [self.resultsController performFetch:&error];
    
    if (!success) {
        NSLog(@"The objects cannot be retrieved");
    }

}

- (void) viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    [self.placesTableView reloadData];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{

    // Return the number of sections.
    //return 1;
     return [[self.resultsController sections] count];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{

    // Return the number of rows in the section.
    //return self.places.count;
    return [[[self.resultsController sections] objectAtIndex:section] numberOfObjects];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *customCell = @"CustomCell";
    
    CustomCell *cell=(CustomCell *)[tableView dequeueReusableCellWithIdentifier:customCell];
    
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"CustomCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    

    
    
    Place* placeObject = (Place*)[resultsController objectAtIndexPath:indexPath];
    [cell.nameLabel setText:placeObject.name];
    [cell.addressLabel setText:placeObject.address];
    [cell.placeImageView setImage:[UIImage imageWithData:placeObject.image]];
  
    
    return cell;
}

#pragma mark - NSFetchedResultsCotrollerDElegate

- (void)controllerWillChangeContent:(NSFetchedResultsController *)controller {
    // The fetch controller is about to start sending change notifications, so prepare the table view for updates.
    [self.placesTableView beginUpdates];
}


- (void)controller:(NSFetchedResultsController *)controller didChangeObject:(id)anObject atIndexPath:(NSIndexPath *)indexPath forChangeType:(NSFetchedResultsChangeType)eventType newIndexPath:(NSIndexPath *)newIndexPath {
    
    switch(eventType) {
        case NSFetchedResultsChangeDelete:
            [self.placesTableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationLeft];
            break;
        default:
            break;
    }
}


- (void)controller:(NSFetchedResultsController *)controller didChangeSection:(id <NSFetchedResultsSectionInfo>)sectionInfo atIndex:(NSUInteger)sectionIndex forChangeType:(NSFetchedResultsChangeType)eventType {
    
    switch(eventType) {
        case NSFetchedResultsChangeDelete:
            [self.placesTableView deleteSections:[NSIndexSet indexSetWithIndex:sectionIndex] withRowAnimation:UITableViewRowAnimationFade];
            break;
        default:
            break;
    }
}


- (void)controllerDidChangeContent:(NSFetchedResultsController *)controller {
    // The fetch controller has sent all current change notifications, so tell the table view to process all updates.
    [self.placesTableView endUpdates];
}



// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.
    return YES;
}



// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        
        //[tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
        Place* placeObject = (Place *)[resultsController objectAtIndexPath:indexPath];
        AppDelegate* delegate = (AppDelegate*) [UIApplication sharedApplication].delegate;
        NSManagedObjectContext *moc = [delegate managedObjectContext];
        
        [[NSFileManager defaultManager] removeItemAtPath:placeObject.notesFile error:nil];
        [moc deleteObject:placeObject];
        
        NSError* error;
        [moc save:&error];
    }   
    else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }
    [tableView reloadData];
}


/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
{
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

//-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
//     NSLog(@"tyk");
//  
//    
//}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 80.0;
}
-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    if([segue.identifier isEqualToString:@"detail"])
    {
        NSLog(@"tyk");
        DetailInfoVIewControllerViewController *detailVC = segue.destinationViewController;
        NSIndexPath *current = [self.tableView indexPathForSelectedRow];
        Place* placeObject = (Place*)[resultsController objectAtIndexPath:current];
        detailVC.name = placeObject.name;
        detailVC.image = [[UIImage alloc ] initWithData: placeObject.image];
        detailVC.notes = placeObject.notesFile;
        detailVC.price =[[NSString alloc] initWithFormat:@"%@",placeObject.price];
        detailVC.address = placeObject.address;
        
    }

}


@end
