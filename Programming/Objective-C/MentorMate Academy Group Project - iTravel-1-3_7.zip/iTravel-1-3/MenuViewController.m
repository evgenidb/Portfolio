//
//  MenuViewController.m
//  iTravel
//
//  Created by Student05 on 2/4/13.
//  Copyright (c) 2013 Student05. All rights reserved.
//

#import "MenuViewController.h"
#import "ChartViewController.h"
#import "ListTableViewController.h"

#import "TemporaryChart.h" // NEED TO DELETE



@implementation MenuViewController\
@synthesize visitedPlaces=_visitedPlaces;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
	// Do any additional setup after loading the view.
//
//    TemporaryChart *a = [[TemporaryChart alloc] initWithCost:50.0];
//    TemporaryChart *b = [[TemporaryChart alloc] initWithCost:78.0];
//    TemporaryChart *c = [[TemporaryChart alloc] initWithCost:57.0];
//    TemporaryChart *d = [[TemporaryChart alloc] initWithCost:90.0];
//    TemporaryChart *e = [[TemporaryChart alloc] initWithCost:25.0];
//    TemporaryChart *f = [[TemporaryChart alloc] initWithCost:67.0];
//    TemporaryChart *g = [[TemporaryChart alloc] initWithCost:40.0];
//    TemporaryChart *h = [[TemporaryChart alloc] initWithCost:100.0];
//    TemporaryChart *q = [[TemporaryChart alloc] initWithCost:100.0];
//    TemporaryChart *j = [[TemporaryChart alloc] initWithCost:100.0];
//    TemporaryChart *aa = [[TemporaryChart alloc] initWithCost:85.0];
//    TemporaryChart *bb = [[TemporaryChart alloc] initWithCost:100.0];
//    TemporaryChart *cc = [[TemporaryChart alloc] initWithCost:100.0];
//    TemporaryChart *dd = [[TemporaryChart alloc] initWithCost:34.0];
//    TemporaryChart *ee = [[TemporaryChart alloc] initWithCost:87.0];
//    TemporaryChart *ff = [[TemporaryChart alloc] initWithCost:30.0];
//    TemporaryChart *gg = [[TemporaryChart alloc] initWithCost:59.0];
//    TemporaryChart *hh = [[TemporaryChart alloc] initWithCost:66.0];
//    TemporaryChart *qq = [[TemporaryChart alloc] initWithCost:77.0];
//    TemporaryChart *jj = [[TemporaryChart alloc] initWithCost:10.0];
//    TemporaryChart *aaa = [[TemporaryChart alloc] initWithCost:50.0];
//    TemporaryChart *bbb = [[TemporaryChart alloc] initWithCost:55.0];
//    TemporaryChart *ccc = [[TemporaryChart alloc] initWithCost:24.0];
//    TemporaryChart *ddd = [[TemporaryChart alloc] initWithCost:29.0];
//    TemporaryChart *eee = [[TemporaryChart alloc] initWithCost:57.0];
//    TemporaryChart *fff = [[TemporaryChart alloc] initWithCost:50.0];
//    TemporaryChart *ggg = [[TemporaryChart alloc] initWithCost:34.0];
//    TemporaryChart *hhh = [[TemporaryChart alloc] initWithCost:50.0];
//    TemporaryChart *jjj = [[TemporaryChart alloc] initWithCost:65.0];
//    TemporaryChart *qqq = [[TemporaryChart alloc] initWithCost:10.0];
    
    
    //self.visitedPlaces =
    //[[NSMutableArray alloc] initWithObjects:a,b,hhh,c,jjj,d,qqq,e,f,aaa,eee,g,h,bbb,q,j,ccc,aa,bb,cc,dd,ddd,fff,ggg,ee,ff,gg,hh,jj,qq, nil];

    self.title = @"Menu";
    }

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{

    if([segue.identifier isEqualToString:@"chart"])
    {
        ChartViewController *chartVC = segue.destinationViewController;
       // chartVC.places =
        //self.visitedPlaces;
        
    }
    if([segue.identifier isEqualToString:@"list"])
    {
        ListTableViewController *listTVC = segue.destinationViewController;
        listTVC.places = self.visitedPlaces;
        
    }
        
}
@end
