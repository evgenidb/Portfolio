//
//  TemporaryChart.h
//  iTravel
//
//  Created by Student05 on 2/5/13.
//  Copyright (c) 2013 Student05. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TemporaryChart : NSObject
@property (nonatomic) NSString *name;
@property (atomic) float cost;

-(id)init;
-(id)initWithCost:(float)number;
-(id)initWithCost:(float)number andName:(NSString *)name;
@end
