//
//  Country.m
//  iTravel
//
//  Created by Student05 on 2/4/13.
//  Copyright (c) 2013 Student05. All rights reserved.
//

#import "Country.h"

@implementation Country

@synthesize name=_name;
@synthesize capital=_capital;
@synthesize continent=_continent;
@synthesize isAnswered=_isAnswered;
@synthesize borders=_borders;
@synthesize flag=_flag;
@synthesize location=_location;

//chaining

-(id)initWithName:(NSString *)countryName andCapital:(NSString *)countryCapital andContinent:(Continent)countryContinent andBorders:(NSString *)countrysBorders andFlag:(NSString *)countrysFlag andLocation:(NSString *)countrysLocation
{
    self = [super init];
    if(self)
    {
        self.name=countryName;
        self.capital=countryCapital;
        self.continent=countryContinent;
        self.borders=countrysBorders;
        self.flag=countrysFlag;
        self.location=countrysLocation;
        self.isAnswered=NO;
    }
    return self;
}

-(id)init{
    return [self initWithName:@"Country Name" andCapital:@"Country Capital" andContinent:0 andBorders:@"Unknown.jpg" andFlag:@"Unknown.jpg" andLocation:@"Unknown.jpg"];
}




@end
