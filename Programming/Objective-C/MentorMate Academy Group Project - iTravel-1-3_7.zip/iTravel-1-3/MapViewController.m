//
//  MapViewController.m
//  iTravel
//
//  Created by Student08 on 2/5/13.
//  Copyright (c) 2013 Student05. All rights reserved.
//

#import "MapViewController.h"
#import "MKMapView+ZoomLevel.h"
#import "LocationContainer.h"
#import "PlaceAnnotation.h"
#import "Place.h"
#import "AppDelegate.h"

#import "JSONParser.h"


@interface MapViewController () <UITextFieldDelegate>
// Properties
// Singletons
@property (nonatomic, readwrite) LocationContainer* sharedLocationContainer;


// UIElements
// MapView
@property (weak, nonatomic) IBOutlet MKMapView *mapView;

// Change Map View
@property (weak, nonatomic) IBOutlet UISegmentedControl *mapType;
@property (weak, nonatomic) IBOutlet UISlider *mapZoom;

// Filter Locations
@property (weak, nonatomic) IBOutlet UILabel *locationTypeFilterLabel;
@property (weak, nonatomic) IBOutlet UITextField *locationTypeFilterInput;
@property (weak, nonatomic) IBOutlet UIButton *locationTypeFilterBtn;



// Toolbar
@property (weak, nonatomic) IBOutlet UIToolbar *toolbar;

// Toolbar Buttons
@property (weak, nonatomic) IBOutlet UIBarButtonItem *toolbarBtn_Zoom;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *toolbarBtn_MapOptions;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *toolbarBtn_NearbyLocations;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *toolbarBtn_ShowUserLocation;


// Methods


@end

@implementation MapViewController


// Methods
// Inits
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.title = @"Map";
        
        
        // Init the Singletons
        [self initSingletons];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    
    // Init UI elements
    [self initializeUIElements];
    
    [self plotVisitedPlaces];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


// Init Singletons
-(void) initSingletons
{
    [self initLocationContainer];
}

-(void) initLocationContainer
{
    if (!self.sharedLocationContainer)
    {
        self.sharedLocationContainer = [LocationContainer sharedLocationContainer];
    }
}



// Init UIElements
-(void) initializeUIElements
{
    // Options
    [self hideOptions:YES];
    
    // Zoom
    [self hideZoom:YES];
    
    // User Locations
    self.mapView.showsUserLocation = YES;
    
    // BUG - not centered at user location!!!
    [self centerMapViewAtUserLocation];
    
    
    [self initializeMapViewZoom];
}


// Center Map View at User Location
-(void) centerMapViewAtUserLocation
{
    self.mapView.centerCoordinate = self.mapView.userLocation.coordinate;
    self.mapView.centerCoordinate = self.mapView.userLocation.coordinate;
}

// Calculate current Zoom and set it to the slider
-(void) initializeMapViewZoom
{
    NSUInteger zoomLevel = 14;
    [self mapViewAtZoomLevel:zoomLevel];
}



// Set Zoom Level
-(void) mapViewAtZoomLevel:(NSUInteger)zoomLevel
{
    self.mapZoom.value = zoomLevel;
    
    CLLocationCoordinate2D centerCoord = self.mapView.region.center;
    [self.mapView setCenterCoordinate:centerCoord zoomLevel:zoomLevel animated:YES];
}


// Set slider value based on User's Gesture recognizer
-(void)mapView: (MKMapView *)mapView regionWillChangeAnimated:(BOOL)animated
{
    // BUG - not changing the slider when zooming with gestures!!!
    NSLog(@"Region Will Change!");
    self.mapZoom.value = (float)[self.mapView getZoomLevelDouble];
}

-(void)mapView:(MKMapView *)mapView regionDidChangeAnimated:(BOOL)animated
{
    // BUG - not changing the slider when zooming with gestures!!!
    NSLog(@"Region Changed!");
    self.mapZoom.value = (float)[self.mapView getZoomLevelDouble];
}


// UI Elements Actions
// Toolbar Buttons
- (IBAction)Zoom:(UIBarButtonItem *)sender
{
    [self toggleZoomBarVisibility];
}

- (IBAction)MapOptions:(UIBarButtonItem *)sender
{
    [self toggleOptionsVisibilty];
}

- (IBAction)ShowNearbyLocations:(UIBarButtonItem *)sender
{
    [self showAllNearbyLocations];
}

- (IBAction)ShowUserLocation:(UIBarButtonItem *)sender
{
    [self centerMapViewAtUserLocation];
}

// Other UI Actions
- (IBAction)switchMapType:(UISegmentedControl *)sender
{
    switch (sender.selectedSegmentIndex) {
        case 0:
            self.mapView.mapType = MKMapTypeStandard;
            break;
            
        case 1:
            self.mapView.mapType = MKMapTypeSatellite;
            break;
            
        case 2:
            self.mapView.mapType = MKMapTypeHybrid;
            break;
            
        default:
            self.mapView.mapType = MKMapTypeStandard;
            break;
    }
    
}

- (IBAction)zoomLevelChanged:(UISlider *)sender
{
    NSUInteger zoomLevel = roundf(self.mapZoom.value);
    
    [self mapViewAtZoomLevel:zoomLevel];
}

- (IBAction)filterNearbyLocationsByType:(UIButton *)sender {
    // TODO: Show locations that are only of given type
    
    [self showLocationsOfType:self.locationTypeFilterInput.text];
    
    [self hideOptions:YES];
    
    [self textFieldShouldReturn:self.locationTypeFilterInput];
    
}

// Toggle Visibility
-(void) toggleZoomBarVisibility
{
    BOOL hide = !self.mapZoom.hidden;
    [self hideZoom:hide];
}

-(void) toggleOptionsVisibilty
{
    BOOL hide = !self.mapType.hidden;
    [self hideOptions:hide];
    
}

-(void) hideZoom:(BOOL)hide
{
    self.mapZoom.hidden = hide;
}

-(void) hideOptions:(BOOL)hide
{
    self.mapType.hidden = hide;
    self.locationTypeFilterLabel.hidden = hide;
    self.locationTypeFilterInput.hidden = hide;
    self.locationTypeFilterBtn.hidden = hide;
}


// Dismiss the Keyboard
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}



// Find nearby locations
-(void) showAllNearbyLocations
{
    NSDictionary* optionsDict = @{
    @"coordinates" : @{
    @"lat" : [NSString stringWithFormat:@"%f", self.mapView.centerCoordinate.latitude],
    @"lng" : [NSString stringWithFormat:@"%f", self.mapView.centerCoordinate.longitude]
    }
    };
    NSArray* locationsOfType = [[[JSONParser alloc] init] getGoogleNearbyLocationsJSONWithOptionsDict:optionsDict];
    
    
    NSLog(@"%u", [locationsOfType count]);
    
    for (Location* location in locationsOfType) {
        // MKPointAnnotation* locationAnnotation = [[MKPointAnnotation alloc] init];
        PlaceAnnotation* locationAnnotation = [[PlaceAnnotation alloc] initWithName:location.name address:location.address coordinate:location.coordinate];
        
        
        [self.mapView addAnnotation:locationAnnotation];
    }
    
}


// Show Locations of type
-(void) showLocationsOfType:(NSString*) locationType
{
    // Search in the temporary locations Storage - won't work if we go to different region!!!
    // NSSet* locationsOfType = [self.sharedLocationContainer getLocationsOfType:locationType];
    
    
    // Use this instead!
    // Use the google Api to return the locations of the desired type
    NSDictionary* optionsDict = @{
    @"type" : @[locationType],
    @"coordinates" : @{
    @"lat" : [NSString stringWithFormat:@"%f", self.mapView.centerCoordinate.latitude],
    @"lng" : [NSString stringWithFormat:@"%f", self.mapView.centerCoordinate.longitude]
    }
    };
    NSArray* locationsOfType = [[[JSONParser alloc] init] getGoogleNearbyLocationsJSONWithOptionsDict:optionsDict];
    
    
    NSLog(@"%u", [locationsOfType count]);
    
    for (Location* location in locationsOfType) {
        // MKPointAnnotation* locationAnnotation = [[MKPointAnnotation alloc] init];
        PlaceAnnotation* locationAnnotation = [[PlaceAnnotation alloc] initWithName:location.name address:location.address coordinate:location.coordinate];
        
        
        [self.mapView addAnnotation:locationAnnotation];
    }
}

- (void) plotVisitedPlaces{
    
    AppDelegate* delegate = (AppDelegate*) [UIApplication sharedApplication].delegate;
	NSManagedObjectContext *moc = [delegate managedObjectContext];
	NSEntityDescription *entityDescription = [NSEntityDescription entityForName:@"Place" inManagedObjectContext:moc];
   // NSSortDescriptor *sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:@"date" ascending:YES];
	NSFetchRequest *request = [[NSFetchRequest alloc] init];
	[request setEntity:entityDescription];
    //[request setSortDescriptors:[NSArray arrayWithObject:sortDescriptor]];
    
    NSError *error;  //TODO handle error
    NSArray * fetchedPlaces =[moc executeFetchRequest:request error:&error];
    
    for (Place *place in  fetchedPlaces) {
        
        
        NSNumber *latitude = place.lat;
        NSNumber *longitude = place.lon;
        NSString *name = place.name;
        NSString *address = place.address;
        
        
        CLLocationCoordinate2D coordinate;
        coordinate.latitude = [latitude doubleValue];
        coordinate.longitude = longitude.doubleValue;
        
        PlaceAnnotation *annotation = [[PlaceAnnotation alloc] initWithName:name address:address coordinate:coordinate];
       
        
        [self.mapView addAnnotation:annotation];
    }
}


/*
 
 - (MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id<MKAnnotation>)annotation{
 
 static NSString *identifier = @"RentAnnotation";
 if ([annotation isKindOfClass:[RentAnnotation class]]) {
 
 MKPinAnnotationView *annotationView = (MKPinAnnotationView *) [self.mapView dequeueReusableAnnotationViewWithIdentifier:identifier];
 if (annotationView == nil) {
 annotationView = [[MKPinAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:identifier];
 } else {
 annotationView.annotation = annotation;
 }
 
 annotationView.enabled = YES;
 annotationView.canShowCallout = YES;
 annotationView.tag = ((RentAnnotation *)annotation).annotationTag;
 UIButton *detailButton = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
 annotationView.rightCalloutAccessoryView = detailButton;
 
 annotationView.pinColor = MKPinAnnotationColorPurple;
 
 return annotationView;
 }
 
 return nil;
 }
 
 - (void)mapView:(MKMapView *)mapView annotationView:(MKAnnotationView *)view calloutAccessoryControlTapped:(UIControl *)control{
 
 DetailViewController *detailVC = [[DetailViewController alloc] init];
 // TODO: Provide Data
 detailVC.placeObject = [self.resultsController objectAtIndexPath:[NSIndexPath indexPathForRow:view.tag inSection:0]];
 [self.navigationController pushViewController:detailVC animated:YES];
 }
 
 
 */

@end
