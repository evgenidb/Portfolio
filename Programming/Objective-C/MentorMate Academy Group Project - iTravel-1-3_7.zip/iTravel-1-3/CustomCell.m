//
//  CustomCell.m
//  iTravel
//
//  Created by Student05 on 2/7/13.
//  Copyright (c) 2013 Student05. All rights reserved.
//

#import "CustomCell.h"

@implementation CustomCell

@synthesize nameLabel = _nameLabel;
@synthesize addressLabel = _addewssLabel;
@synthesize placeImageView = _placeImageView;



- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
