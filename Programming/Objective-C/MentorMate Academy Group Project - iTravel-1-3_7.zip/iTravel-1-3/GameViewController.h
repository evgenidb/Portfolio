//
//  GameViewController.h
//  iTravel
//
//  Created by Student05 on 2/4/13.
//  Copyright (c) 2013 Student05. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GameViewController : UIViewController <UIAlertViewDelegate,UITextFieldDelegate>

@property (weak, nonatomic) IBOutlet UILabel *countryContinent;     //CONTINENT
@property (weak, nonatomic) IBOutlet UIImageView *countryImage;     //BORDERS WITH THE FLAG IN IT
@property (weak, nonatomic) IBOutlet UILabel *hintLabel;            //HINT - (FIRST AND LAST LETTER OF THE CAPITAL)
@property (weak, nonatomic) IBOutlet UITextField *answerTextField;  //ANSWER - TEXT FIELD FOR THE CAPITAL
@property (weak, nonatomic) IBOutlet UILabel *wrongAnswerLabel;     //WRONG ANSWER LABEL
@property (weak, nonatomic) IBOutlet UIImageView *countrysFlag;     //FLAG
@property (weak, nonatomic) IBOutlet UIImageView *countrysLocation; //LOCATION IN THE GLOBE
@property (weak, nonatomic) IBOutlet UILabel *scoreLabel;

@property int score;


- (IBAction)useHintButton:(id)sender;
- (IBAction)answerButton:(id)sender;
- (IBAction)backgrondTouched:(id)sender;
- (IBAction)textFieldShouldReturn:(id)sender;
- (IBAction)textFieldBeganEditing:(id)sender;



@end
