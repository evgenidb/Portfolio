//
//  LocationContainer.m
//  iTravel
//
//  Created by Student08 on 2/8/13.
//  Copyright (c) 2013 Student05. All rights reserved.
//

#import "LocationContainer.h"

@interface LocationContainer()

// Properties
@property (nonatomic, readwrite) NSMutableSet* locations;

@end


@implementation LocationContainer


// Methods
// For singleton
+(LocationContainer*) sharedLocationContainer
{
    static LocationContainer *sharedLocationContainer;
    
    @synchronized(self)
    {
        if (sharedLocationContainer == nil) {
            sharedLocationContainer = [[LocationContainer alloc] init];
        }
    }
    
    return sharedLocationContainer;
}

// Add/Remove Hotels
-(void) addLocation:(Location *)locationToAdd
{
    // If the location set does't exist - create it
    if (self.locations == nil)
    {
        self.locations = [[NSMutableSet alloc] initWithCapacity:1];
    }
    
    
    // Add the hotel to the set
    [self.locations addObject:locationToAdd];
}

-(void) removeLocation:(Location *)locationToRemove
{
    [self.locations removeObject:locationToRemove];
}

-(void) removeAllLocations
{
    [self.locations removeAllObjects];
}


// Getters
-(NSSet*) getLocationsOfType:(NSString *)searchedType
{
    NSMutableSet* locationsOfType = [[NSMutableSet alloc] initWithCapacity:0];
    
    for (Location* loc in self.locations)
    {
        if ([loc isLocationOfType:searchedType])
        {
            [locationsOfType addObject:loc];
        }
    }
    
    return [NSSet setWithSet:locationsOfType];
}


@end
