//
//  DetailInfoVIewControllerViewController.m
//  iTravel
//
//  Created by Student05 on 2/7/13.
//  Copyright (c) 2013 Student05. All rights reserved.
//

#import "DetailInfoVIewControllerViewController.h"

@interface DetailInfoVIewControllerViewController ()

@end

@implementation DetailInfoVIewControllerViewController
@synthesize pictureImageView = _pictureImageView;
@synthesize namePlaceLabel = _namePlaceLabel;
@synthesize addressPlaceLabel = _addressPlaceLabel;
@synthesize additionalTextLabel = _additionalTextLabel;
@synthesize costLabel = _costLabel;
@synthesize price =_price;
@synthesize image=_image;
@synthesize notes=_notes;
@synthesize name=_name;
@synthesize address=_address;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    self.namePlaceLabel.text = self.name;
    self.pictureImageView.image = self.image;
    self.additionalTextLabel.text = [NSString stringWithContentsOfFile:self.notes encoding:NSUTF8StringEncoding error:nil];
    self.costLabel.text = self.price;
    self.addressPlaceLabel.text =self.address;
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
