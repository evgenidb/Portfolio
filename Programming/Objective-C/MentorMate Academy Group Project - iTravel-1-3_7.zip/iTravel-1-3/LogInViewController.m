//
//  LogInViewController.m
//  iTravel
//
//  Created by Student05 on 2/4/13.
//  Copyright (c) 2013 Student05. All rights reserved.
//

#import "LogInViewController.h"
#import "MenuViewController.h"


@interface LogInViewController ()

@end

@implementation LogInViewController 

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.title = @"Log In Screen";


    
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


//-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
//    if ([segue.identifier isEqualToString:@"facebook"]) {
//        
//        if([SLComposeViewController isAvailableForServiceType:SLServiceTypeFacebook])
//        {
//            slComposeViewController = [SLComposeViewController composeViewControllerForServiceType:SLServiceTypeFacebook];
//            [self presentViewController:slComposeViewController animated:YES completion:NULL];
//        }
//        else
//        {
//            UIAlertView *allert = [[UIAlertView alloc] initWithTitle:@"No Facebook Acoount" message:@"you have to log in from accounts" delegate:nil cancelButtonTitle:@"Dismiss" otherButtonTitles: nil];
//            [allert show];
//           
//        }
//    }
//
//}


@end
