//
//  JSONParser.m
//  iTravel
//
//  Created by Student08 on 2/8/13.
//  Copyright (c) 2013 Student05. All rights reserved.
//

#import <MapKit/MapKit.h>
#import "JSONParser.h"
#import "LocationContainer.h"


// Define Keys for APIs
// Get the keys for those who have 0000s in them
#define GOOGLE_PLACES_KEY @"AIzaSyBgCGlQrui3DtG29RQt0a9rTulGK1ybluc"
// #define GOOGLE_GEOCODING_KEY @"AIzaSyBiIOW-e-VjgkQtnFyAexETYqUNNq-P-Zs"

// Define Default key if no key is passed
#define DEFAULT_KEY @"00000"


@interface JSONParser () <CLLocationManagerDelegate>

@end


@implementation JSONParser


// JSON Parser Wrappers
- (NSArray *) getGoogleNearbyLocationsJSONWithOptionsDict:(NSDictionary*)optionsDict
{
    // Just for testing
    NSLog(@"NearbyLocations");
    
    
    // Correct the optionsDict if needed
    NSDictionary* correctedOptionsDict = [self createOptionsDictionaryFromNormalDictionary:optionsDict
                                                               andNecessaryOptionsSelector:@selector(putTheNecessaryOptionsForNearbyLocationsDict:)];
    
    
    
    // Construct the link similar to this one:
    // NSString* urlJSON = [NSString stringWithFormat: @"https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=-33.8670522,151.1957362&radius=500&types=food&name=harbour&sensor=false&key=AddYourOwnKeyHere" ];
    
    NSString* startURL = @"https://maps.googleapis.com/maps/api/place/nearbysearch/json";
    NSString* endURL = @"";
    
    NSString* urlJSON = [self urlJSONconstructorWithStartOfURL: startURL
                                   doNeedToPreAppendQueryStart: YES
                                                   withOptions: correctedOptionsDict
                                                   andEndOfURL: endURL];
    
    //Get JSON response
    NSURL *url = [NSURL URLWithString: urlJSON];
    // NSLog(@"%@",url);
    NSData *jsonData = [NSData dataWithContentsOfURL: url];
    // NSString *str = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    
    // NSLog(@"%@",str );
    
    //Serialize NSData JSON to Dictionary
    NSError *jsonSerializationError;
    NSDictionary *jsonDictionary = [NSJSONSerialization JSONObjectWithData: jsonData options: 0 error: &jsonSerializationError];
    
    if (jsonSerializationError) {
        NSLog(@"Error in json serialization: %@", jsonSerializationError.description);
    }
    
    NSLog(@"JSON Dict %@", jsonDictionary);
    
    // Contains an array of nearby Locaations
    NSArray* nearbyLocationsArray = [self parseNearbyLocationsFromJSONDict:jsonDictionary];
    
    NSLog(@"Locations count: %u", nearbyLocationsArray.count);
    
    return nearbyLocationsArray;
}


- (NSArray *) getGoogleGeocodingJSONWithLocationCoordinates:(NSDictionary*)optionsDict
{
    // Just for testing
    NSLog(@"Geocoding");
    
    
    
    // Correct the optionsDict if needed
    NSDictionary* correctedOptionsDict = [self createOptionsDictionaryFromNormalDictionary:optionsDict
                                                               andNecessaryOptionsSelector:@selector(putTheNecessaryOptionsForGeocodingDict:)];
    
    
    
    // Construct the link similar to this one:
    // NSString* urlJSON = [NSString stringWithFormat: @"http://maps.googleapis.com/maps/api/geocode/json?latlng=40.714224,-73.961452&sensor=true" ];
    
    NSString* startURL = @"http://maps.googleapis.com/maps/api/geocode/json";
    NSString* endURL = @"";
    
    NSString* urlJSON = [self urlJSONconstructorWithStartOfURL: startURL
                                   doNeedToPreAppendQueryStart: YES
                                                   withOptions: correctedOptionsDict
                                                   andEndOfURL: endURL];
    
    //Get JSON response
    NSURL *url = [NSURL URLWithString: urlJSON];
    NSData *jsonData = [NSData dataWithContentsOfURL: url];
    
    
    //Serialize NSData JSON to Dictionary
    NSError *jsonSerializationError;
    NSDictionary *jsonDictionary = [NSJSONSerialization JSONObjectWithData: jsonData options: 0 error: &jsonSerializationError];
    
    if (jsonSerializationError) {
        NSLog(@"Error in json serialization: %@", jsonSerializationError.description);
    }
    
    // NSLog(@"jsonDict: %@ for coordinates: %@", jsonDictionary, optionsDict);
    
    // Contains an array of nearby Locaations
    NSArray* locationAddressesArray = [self parseLocationAddressesFromJSONDict:jsonDictionary];
    
    NSLog(@"Address count: %u", locationAddressesArray.count);
    
    return locationAddressesArray;
}





// Helper Methods
// JSON Parsers
- (NSArray*) parseNearbyLocationsFromJSONDict:(NSDictionary*)jsonDict
{
    NSLog(@"Entered parseNearbyLocationsFromJSONDict:");
    NSMutableArray* nearbyLocations = [[NSMutableArray alloc] initWithCapacity:0];
    
    
    // Check if the status is "OK". If not return the empty array
    if (![jsonDict[@"status"] isEqualToString:@"OK"]) {
        return [NSArray arrayWithArray:nearbyLocations];
    }
    
    
    //Parse JSON Dictionary to get important data
    // We need:
    // - address - can't get it from here
    // - locationCoordinate
    // - name
    // - type
    // - icon
    
    // NSLog(@"%@", jsonDict);
    
    for (NSDictionary* location in jsonDict[@"results"])
    {
        NSLog(@"New Location");
        NSMutableDictionary* locationDict = [[NSMutableDictionary alloc] initWithCapacity:0];
        
        locationDict[@"locationID"] = location[@"id"];
        locationDict[@"name"] = location[@"name"];
        locationDict[@"coordinate"] = location[@"geometry"][@"location"];
        locationDict[@"icon"] = location[@"icon"];
        locationDict[@"types"] = [NSSet setWithArray:location[@"types"]];
        
        NSDictionary* optionsDict = @{@"latlng" : [self convertCoordinatesToString:location[@"geometry"][@"location"]]};
        
        
        NSLog(@"Before address");
        id address = [[self getGoogleGeocodingJSONWithLocationCoordinates:optionsDict] lastObject];
        if (address == nil) {
            locationDict[@"address"] = @"";
        }
        else
        {
            locationDict[@"address"] = address;
        }
        
        NSLog(@"After address");
        
        
        Location* nearbyLocation = [[Location alloc] initLocationWithDict:locationDict];
        
        [nearbyLocations addObject:nearbyLocation];
    }
    
    
    NSLog(@"Exit of parseNearbyLocationsFromJSONDict:");
    return [NSArray arrayWithArray:nearbyLocations];
}


- (NSArray*) parseLocationAddressesFromJSONDict:(NSDictionary*)jsonDict
{
    NSMutableArray* locationAddresses = [[NSMutableArray alloc] initWithCapacity:0];
    
    
    // Check if the status is "OK". If not return the empty array
    if (![jsonDict[@"status"] isEqualToString:@"OK"]) {
        return [NSArray arrayWithArray:locationAddresses];
    }
    
    
    //Parse JSON Dictionary to get important data
    // We need:
    // - address - formatted_address
    
    NSLog(@"Geocoding jsonDict: %@", jsonDict);
    
    for (NSDictionary* location in jsonDict[@"results"])
    {
        [locationAddresses addObject:location[@"formatted_address"]];
    }
    
    return [NSArray arrayWithArray:locationAddresses];
}








// URL constructor
- (NSString*)urlJSONconstructorWithStartOfURL:(NSString*)startURL
                  doNeedToPreAppendQueryStart:(BOOL)needToPreAppendQueryStart
                                  withOptions:(NSDictionary*) optionsDict
                                  andEndOfURL:(NSString*)endURL
{
    NSMutableString* strOptions = [NSMutableString stringWithString:@""];
    
    BOOL needToPreAppendAND = NO;
    // Construct the options
    for (NSString* optionKey in optionsDict.allKeys)
    {
        if (needToPreAppendAND) {
            [strOptions appendString:@"&"];
        }
        else if (needToPreAppendQueryStart)
        {
            // Will be done only the first time
            [strOptions appendString:@"?"];
        }
        
        [strOptions appendFormat:@"%@=%@",optionKey, optionsDict[optionKey]];
        needToPreAppendAND = YES;
    }
    
    return [NSString stringWithFormat:@"%@%@%@", startURL, strOptions, endURL];
}


// Options Dictionary Converter
- (NSDictionary*) createOptionsDictionaryFromNormalDictionary:(NSDictionary*) dict
                                  andNecessaryOptionsSelector:(SEL) necessaryOptionsSelector
{
    // Just for testing
    NSLog(@"CreateOptionsDictionary");
    
    
    NSMutableDictionary* correctedOptionsDictionary = [[NSMutableDictionary alloc] initWithCapacity:0];
    
    
    for (NSString* key in dict.allKeys)
    {
        if ([key isEqualToString:@"coordinates"])
        {
            correctedOptionsDictionary[@"location"] = [self convertCoordinatesToString:dict[key]];
        }
        else if ([key isEqualToString:@"types"])
        {
            correctedOptionsDictionary[key] = [self convertTypesToString:dict[key]];
        }
        else
        {
            // Just add the new key-value normally
            correctedOptionsDictionary[key] = dict[key];
        }
    }
    
    /*
     // No need for this! We do it in the selector for necessaryOptions!
     // Put the access key
     correctedOptionsDictionary[@"key"] = accessKey;
     */
    
    // Check if the correctedOptionsDict contains the necessary location and radius
    // correctedOptionsDictionary = [self putTheNecessaryOptionsForNearbyLocationsDict:correctedOptionsDictionary];
    
    if (necessaryOptionsSelector != nil) {
        // Just for testing
        NSLog(@"Will Perform Selector");
        
        
        correctedOptionsDictionary = [self performSelector:necessaryOptionsSelector withObject:correctedOptionsDictionary];
        
        // Just for testing
        NSLog(@"Did Perform Selector");
    }
    
    
    
    
    return [NSDictionary dictionaryWithDictionary:correctedOptionsDictionary];
}


// Conversion from normal Dict data to String to pass to the JSON
-(NSString*) convertCoordinatesToString:(NSDictionary*)coordinateDict
{
    CLLocationCoordinate2D coordinate = CLLocationCoordinate2DMake([coordinateDict[@"lat"] doubleValue], [coordinateDict[@"lng"] doubleValue]);
    
    return [self convertCLCoordinateToString:coordinate];
}

-(NSString*) convertCLCoordinateToString:(CLLocationCoordinate2D)coordinate
{
    return [NSString stringWithFormat:@"%f,%f", coordinate.latitude, coordinate.longitude];
}

-(NSString*) convertTypesToString:(NSArray*)typesArray
{
    NSMutableString* typesArrayToString = [[NSMutableString alloc] initWithString:@""];
    
    BOOL needToPreAppendOR = NO;
    
    for (NSString* type in typesArray)
    {
        // We need this for "type1|type2|type3"...
        if (needToPreAppendOR) {
            [typesArrayToString appendString:@"|"];
        }
        
        [typesArrayToString appendString:type];
        needToPreAppendOR = YES;
    }
    
    return [NSString stringWithString:typesArrayToString];
}

// Necessary Options
-(NSMutableDictionary*) putTheNecessaryOptionsForNearbyLocationsDict:(NSMutableDictionary*)optionsDict
{
    NSLog(@"Selector performed on putTheNecessaryOptionsForNearbyLocationsDict");
    
    if (![optionsDict.allKeys containsObject:@"location"])
    {
        // TODO: If there's no location - use User Location
        optionsDict[@"location"] = [self convertCLCoordinateToString:[self returnUserCoordinates]];
    }
    
    if (![optionsDict.allKeys containsObject:@"radius"])
    {
        // Use Standard Radius
        
        optionsDict[@"radius"] = [NSString stringWithFormat:@"%d", 2000];
    }
    
    if (![optionsDict.allKeys containsObject:@"sensor"])
    {
        // Set to true since we're using mobile device and we should be using it with User Location
        optionsDict[@"sensor"] = @"true";
    }
    
    // Set the key - it's always the same!
    if (![optionsDict.allKeys containsObject:@"key"])
    {
        // Use this "key" if one is not specified!
        optionsDict[@"key"] = GOOGLE_PLACES_KEY;
    }
    
    
    return optionsDict;
}

-(NSMutableDictionary*) putTheNecessaryOptionsForGeocodingDict:(NSMutableDictionary*)optionsDict
{
    NSLog(@"Selector performed on putTheNecessaryOptionsForGeocodingDict");
    
    if (![optionsDict.allKeys containsObject:@"latlng"])
    {
        // TODO: If there's no location - use User Location
        optionsDict[@"latlng"] = [self convertCLCoordinateToString:[self returnUserCoordinates]];
    }
    
    if (![optionsDict.allKeys containsObject:@"sensor"])
    {
        // Set to true since we're using mobile device and we should be using it with User Location
        optionsDict[@"sensor"] = @"true";
    }
    
    // Set the key - it's always the same!
    
    /*
     // No need for key for this API
     if (![optionsDict.allKeys containsObject:@"key"])
     {
     // Use this "key" if one is not specified!
     optionsDict[@"key"] = GOOGLE_GEOCODING_KEY;
     }
     */
    
    return optionsDict;
}



-(CLLocationCoordinate2D) returnUserCoordinates
{
    CLLocationManager *locationManager = [[CLLocationManager alloc] init];
    locationManager.delegate = self;
    
    locationManager.desiredAccuracy = kCLLocationAccuracyBest;
    locationManager.distanceFilter = kCLDistanceFilterNone;
    
    [locationManager startUpdatingLocation];
    
    CLLocationCoordinate2D coordinates = locationManager.location.coordinate;
    
    [locationManager stopUpdatingLocation];
    
    return coordinates;
}


/*
 // Methods from Location Manager delegate
 - (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation ;
 
 - (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error;
 */



// Methods For Testing
// Test the Parsers
-(BOOL) testParseGoogleNearbyLocationsJSONWithOptionsDict
{
    NSDictionary* optionsDict = @{
    @"key" : @"0000",
    @"location" : @"-33.8670522,151.1957362",
    @"radius" : @"2000",
    @"types" : @"food|cafe"
    };
    
    NSArray* locationsArray = [self getGoogleNearbyLocationsJSONWithOptionsDict:optionsDict];
    
    // Print the location data
    NSLog(@"%u", [locationsArray count]);
    for (Location* loc in locationsArray)
    {
        NSLog(@"");
        NSLog(@"%@", loc.name);
        NSLog(@"%@", loc.address);
        NSLog(@"");
    }
    
    
    return YES;
}

@end
