//
//  ChartViewController.m
//  iTravel
//
//  Created by Student05 on 2/4/13.
//  Copyright (c) 2013 Student05. All rights reserved.
//

#import "ChartViewController.h"
#import "ChartView.h"
#import "AppDelegate.h"
#import "Place.h"
#import "TemporaryChart.h"

@implementation ChartViewController
@synthesize width=_width;
@synthesize places=_places;



- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    self.title = @"Chart";
    
    AppDelegate* delegate = (AppDelegate*) [UIApplication sharedApplication].delegate;
	NSManagedObjectContext *moc = [delegate managedObjectContext];
	NSEntityDescription *entityDescription = [NSEntityDescription entityForName:@"Place" inManagedObjectContext:moc];
    NSSortDescriptor *sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:@"date" ascending:YES];
	NSFetchRequest *request = [[NSFetchRequest alloc] init];
	[request setEntity:entityDescription];
    [request setSortDescriptors:[NSArray arrayWithObject:sortDescriptor]];
    
    NSError *error;
    NSArray * fetchedPlaces =[moc executeFetchRequest:request error:&error];
    
    self.places = [[NSMutableArray alloc] initWithCapacity:[fetchedPlaces count]];
    
    
    for (Place *place in fetchedPlaces) {
        TemporaryChart *tempChart = [[TemporaryChart alloc] initWithCost:[place.price floatValue] andName:place.name];  //Bad Practice
        [self.places addObject:tempChart];
        NSLog(@"%@ at %@",place.name,place.date);
    }
    
    self.width = ([self.places count]*40) +([self.places count]+2)*10;
    [self.chartScroolView setScrollEnabled:YES];
    if(self.width<300)
    {
        [self.chartScroolView setContentSize:CGSizeMake(320, 400)];
        [self.chartScroolView setFrame:CGRectMake(0, 0, 320, 400)];//CONSTANT
        //ChartView *chartView = [[ChartView alloc] initWithFrame:CGRectMake(5, 5, 310, 390)];
        ChartView *chartView = [[ChartView alloc] initWithFrame:CGRectMake(5, 5, 310, 390) andPlaces:self.places];
        chartView.backgroundColor = [UIColor whiteColor];
        [self.chartScroolView addSubview:chartView];

    }
    else
    {
        [self.chartScroolView setContentSize:CGSizeMake(self.width, 400)];
        [self.chartScroolView setFrame:CGRectMake(0, 0, 320, 400)];//CONSTANT
        ChartView *chartView = [[ChartView alloc] initWithFrame:CGRectMake(5, 5, self.width-10, 390) andPlaces:self.places];
        chartView.backgroundColor = [UIColor whiteColor];
        [self.chartScroolView addSubview:chartView];
        
    }

    
    [super viewDidLoad];

    
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
