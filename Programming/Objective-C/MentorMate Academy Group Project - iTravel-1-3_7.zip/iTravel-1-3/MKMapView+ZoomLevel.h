//
//  MKMapView+ZoomLevel.h
//  iTravel
//
//  Created by Student08 on 2/5/13.
//  Copyright (c) 2013 Student05. All rights reserved.
//

#import <MapKit/MapKit.h>

@interface MKMapView (ZoomLevel)

- (void)setCenterCoordinate:(CLLocationCoordinate2D)centerCoordinate
                  zoomLevel:(NSUInteger)zoomLevel
                   animated:(BOOL)animated;

- (int) getZoomLevel;

- (double)getZoomLevelDouble;

@end
