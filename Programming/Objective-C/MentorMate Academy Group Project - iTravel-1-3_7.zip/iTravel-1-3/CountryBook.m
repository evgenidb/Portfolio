//
//  CountryBook.m
//  iTravel
//
//  Created by Student05 on 2/4/13.
//  Copyright (c) 2013 Student05. All rights reserved.
//

#import "CountryBook.h"
@interface CountryBook()

@property (nonatomic,strong) NSMutableArray *countrysDictionary;

@end


@implementation CountryBook
@synthesize countrysDictionary=_countrysDictionary;

- (id)init
{
    self = [super init];
    if (self) {
        Country *c0 = [[Country alloc] initWithName:@"Algeria" andCapital:@"Algiers" andContinent:2 andBorders:@"algeriaB.png" andFlag:@"algeria.png" andLocation:@"algeriaL.png"];
        Country *c1 = [[Country alloc] initWithName:@"Angola" andCapital:@"Luanda" andContinent:0 andBorders:@"angolaB.png" andFlag:@"angola.png" andLocation:@"angolaL"];
        Country *c2 = [[Country alloc] initWithName:@"Benin" andCapital:@"Porto-Novo" andContinent:2 andBorders:@"beninB.png" andFlag:@"benin.png" andLocation:@"beninL.png"];
        Country *c3 = [[Country alloc] initWithName:@"Botswana" andCapital:@"Gaborone" andContinent:2 andBorders:@"botswanaB.png" andFlag:@"botswana.png" andLocation:@"botswanaL.png"];
        Country *c4 = [[Country alloc] initWithName:@"Burkina Faso" andCapital:@"Ouagadougou" andContinent:2 andBorders:@"burkinaB.png" andFlag:@"burkina.png" andLocation:@"burkinaL.png"];
        Country *c5 = [[Country alloc] initWithName:@"Burundi" andCapital:@"Bujumbura" andContinent:2 andBorders:@"burundiB.png" andFlag:@"burundi.png" andLocation:@"burundiL.png"];
        Country *c6 = [[Country alloc] initWithName:@"Cameroon" andCapital:@"Yaounde" andContinent:2 andBorders:@"cameroonB.png" andFlag:@"cameroon.png" andLocation:@"cameroonL.png"];
        Country *c7 = [[Country alloc] initWithName:@"Cape Verde" andCapital:@"Praia" andContinent:2 andBorders:@"capeVerdeB.png" andFlag:@"capeVerde.png" andLocation:@"capeVerdeL.png"];
        Country *c8 = [[Country alloc] initWithName:@"Central African Republic" andCapital:@"Bangui" andContinent:2 andBorders:@"centralB.png" andFlag:@"centralAfricanRepublic.png" andLocation:@"centralAfricanRepublicL.png"];
        Country *c9 = [[Country alloc] initWithName:@"Chad" andCapital:@"N'Djamena" andContinent:2 andBorders:@"chadB.png" andFlag:@"chad.png" andLocation:@"chadL.png"];
        //        Country *c10 = [[Country alloc] initWithName:@"Comoros" andCapital:@"Moroni" andContinent:2];
        //        Country *c11 = [[Country alloc] initWithName:@"Congo" andCapital:@"Brazzavolle" andContinent:2];
        //        Country *c12 = [[Country alloc] initWithName:@"Democratic Republic Of Congo" andCapital:@"Kinshasa" andContinent:2];
        //        Country *c13 = [[Country alloc] initWithName:@"Djibouti" andCapital:@"Djibouti" andContinent:3];
        //        Country *c14 = [[Country alloc] initWithName:@"Egypt" andCapital:@"Cairo" andContinent:3];
        //        Country *c15 = [[Country alloc] initWithName:@"Equatorial Guinea" andCapital:@"Malabo" andContinent:3];
        //        Country *c16 = [[Country alloc] initWithName:@"Eritrea" andCapital:@"Asmara" andContinent:5];
        //        Country *c17 = [[Country alloc] initWithName:@"Ethiopia" andCapital:@"Addis Ababa" andContinent:5];
        //        Country *c18 = [[Country alloc] initWithName:@"Gabon" andCapital:@"Libreville" andContinent:5];
        //        Country *c19 = [[Country alloc] initWithName:@"Gambia" andCapital:@"Banjul" andContinent:5];
        
        
        
        
        
        
        self.countrysDictionary = [[NSMutableArray alloc] initWithObjects:c0,c1,c2,c3,c4,c5,c6,c7,c8,c9,nil];
        
        //                                                                c10,c11,c12,c13,c14,c15,c16,c17,c18,c19,
        //                                                                c20,c21,c22,c23,c24,c25,c26,c27,c28,c29,
        //                                                                c30,c31,c32,c33,c34,c35,c36,c37,c38,c39,
        //                                                                c40,c41,c42,c43,c44,c45,c46,c47,c48,c49,
        //                                                                c50,c51,c52,c53,c54,c55,c56,c57,c58,c59,
        //                                                                c60,c61,c62,c63,c64,c65,c66,c67,c68,c69,
        //                                                                c70,c71,c72,c73,c74,c75,c76,c77,c78,c79,
        //                                                                c80,c81,c82,c83,c84,c85,c86,c87,c88,c89,
        //                                                                c90,c91,c92,c93,c94,c95,c96,c97,c98,c99,
        //                                                      c100,c101,c102,c103,c104,c105,c106,c107,c108,c109,
        //                                                      c110,c111,c112,c113,c114,c115,c116,c117,c118,c119,
        //                                                      c120,c121,c122,c123,c124,c125,c126,c127,c128,c129,
        //                                                      c130,c131,c132,c133,c134,c135,c136,c137,c138,c139,
        //                                                      c140,c141,c142,c143,c144,c145,c146,c147,c148,c149,
        //                                                      c150,c151,c152,c153,c154,c155,c156,c157,c158,c159,
        //                                                      c160,c161,c162,c163,c164,c165,c166,c167,c168,c169,
        //                                                      c170,c171,c172,c173,c174,c175,c176,c177,c178,c179,
        //                                                      c180,c181,c182,c183,c184,c185,c186,c187,c188,c189,
        //                                                      c190,c191,c192,c193,nil];
        
    }
    return self;
}
+(id)alloc
{
    return [self sharedInstance];
}
+(id)sharedInstance
{
    static CountryBook* instance=nil;
    if(!instance){
        instance = [[super alloc] init];
        
    }
    return instance;
}

-(Country *)countryAtIndex:(NSUInteger)index{
    return [self.countrysDictionary objectAtIndex:index];//if parsed the code doesnt work at all
}
-(Country *)countryatRandomIndex{
    NSUInteger randomIndex = arc4random() %  [self.countrysDictionary count];
    while ([[self.countrysDictionary objectAtIndex:randomIndex] isAnswered] == YES) {
        randomIndex = arc4random() %  [self.countrysDictionary count];
    }
    return [self.countrysDictionary objectAtIndex:randomIndex];
    
}
-(int)numberOfCountries{
    return [self.countrysDictionary count];
}

@end
