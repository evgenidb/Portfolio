//
//  Country.h
//  iTravel
//
//  Created by Student05 on 2/4/13.
//  Copyright (c) 2013 Student05. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef enum  {             //
    Antarctica  = 0,        //
    Australia = 1,          //
    Africa = 2,             //  Country's
    Asia = 3,               //  CONTINENT
    Europe = 4,             //
    SouthAmerica = 5,       //
    NorthAmerica = 6        //
}Continent;                 //

@interface Country : NSObject

@property (nonatomic,strong) NSString *name;
@property (nonatomic,strong) NSString *capital;
@property (atomic) Continent continent;
@property (nonatomic,strong) NSString *borders;
@property (nonatomic,strong) NSString *flag;
@property (nonatomic,strong) NSString *location;

@property (nonatomic) BOOL isAnswered;              //for the question


-(id)init;
-(id)initWithName:(NSString *)countryName andCapital:(NSString *)countryCapital andContinent:(Continent)countryContinent andBorders:(NSString *)countrysBorders andFlag:(NSString *)countrysFlag andLocation:(NSString *)countrysLocation;



@end
