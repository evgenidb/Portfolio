//
//  ChartView.m
//  iTravel
//
//  Created by Student05 on 2/5/13.
//  Copyright (c) 2013 Student05. All rights reserved.
//

#import "ChartView.h"
#import "TemporaryChart.h" //Need to Delete

@interface ChartView(){
}
@end
@implementation ChartView
@synthesize placesToDraw=_placesToDraw;


- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

-(id)initWithFrame:(CGRect)frame andPlaces:(NSMutableArray *)places{
    self=[super initWithFrame:frame];
    if(self){
        _placesToDraw = [[NSMutableArray alloc] initWithArray:places];
    }
    return self;
    
}

- (void)drawRect:(CGRect)rect
{

    CGContextRef context1 = UIGraphicsGetCurrentContext();              // getting the current context
 
    CGContextTranslateCTM(context1,0, self.frame.size.height);          // rotating the coordinate
    CGContextScaleCTM(context1, 1, -1);                                 // system
    
    
    CGColorSpaceRef colorspace = CGColorSpaceCreateDeviceRGB();         //
    CGFloat components[] = {0.0,0.0,0.0,1.0};                           // THE COLOR
    CGColorRef color = CGColorCreate(colorspace, components);           //
    
    CGColorSpaceRef colorspaceNet = CGColorSpaceCreateDeviceRGB();         //
    CGFloat componentsNet[] = {0.5,0.5,0.5,1.0};                           // THE COLOR FOR THE NET
    CGColorRef colorNet = CGColorCreate(colorspaceNet, componentsNet);     //
    
    

 
    for (int i=0; i<self.frame.size.width; i=i+20) {
        CGContextSetLineWidth(context1, 0.5);                                   //
        CGContextSetStrokeColorWithColor(context1, colorNet);                   // Drawing
        CGContextMoveToPoint(context1, i, 0.0);                                 // Net
        CGContextAddLineToPoint(context1, i,self.frame.size.height);            //
        CGContextStrokePath(context1);
            
    }

    for (int i=0; i<self.frame.size.height; i=i+20) {
        CGContextSetLineWidth(context1, 0.5);                                   //
        CGContextSetStrokeColorWithColor(context1, colorNet);                   // Drawing
        CGContextMoveToPoint(context1,0.0,i);                                   // Net
        CGContextAddLineToPoint(context1,self.frame.size.width,i);              //
        CGContextStrokePath(context1);                                          
    }
    
    
    
        
    CGContextSetLineWidth(context1, 3);                                 //
    CGContextSetStrokeColorWithColor(context1, color);                  // Vertical
    CGContextMoveToPoint(context1, 5, 5);                               // line
    CGContextAddLineToPoint(context1, 5, 385);                          //
    CGContextStrokePath(context1);                                      //
    

    CGContextSetLineWidth(context1, 3);                                 //
    CGContextSetStrokeColorWithColor(context1, color);                  // Horizontal
    CGContextMoveToPoint(context1, 5, 5);                               // line
    CGContextAddLineToPoint(context1, self.frame.size.width-5, 5);      //
    CGContextStrokePath(context1);                                      //

    
    //this lines of code are drwaing the rectangles representing the value of an objects cost value
    
    TemporaryChart *max = [[TemporaryChart alloc] init];            //
    for (int i = 0; i<self.placesToDraw.count; i++) {               //
        if(max.cost<[[self.placesToDraw objectAtIndex:i] cost]){    // finds the max value
            max=[self.placesToDraw objectAtIndex:i];                // of the cost
        }                                                           //
    }                                                               //
    
    
    CGFloat chartVariableY = 0.0;                                                                           
    CGFloat chartVariableHeight = 0.0;
    CGFloat x = 10.0;                                                                                  
    CGFloat displacement = 0.0;
    CGRect rects[self.placesToDraw.count];
    CGFloat red = arc4random() %11*0.1;
    CGFloat green = arc4random() %11*0.1;
    CGFloat blue = arc4random() %11*0.1;
    UIColor *colorOne;
    const char *cStringName;
    const char *cStringCost;
    NSString *costValue;
    for (int i=0; i<self.placesToDraw.count; i++) {
        
        chartVariableY=80.0+((max.cost-[[self.placesToDraw objectAtIndex:i] cost])/max.cost)*300.0;
        chartVariableHeight=([[self.placesToDraw objectAtIndex:i] cost]/max.cost)*300.0;
        
        
        rects[i] = CGRectMake(x+displacement, 10, 40, chartVariableHeight);     //
        CGContextAddRect(context1, rects[i]);                                   // Adds colored
        colorOne=[UIColor colorWithRed:red green:green blue:blue alpha:1.0];    // rectangle
        [colorOne setFill];                                                     // 
        CGContextFillPath(context1);                                            //
        
        displacement=displacement+50.0;         // setting displacement for the other rectangle
        red = arc4random() %11*0.1;             // random red indicator
        green = arc4random() %11*0.1;           // random green indicator
        blue = arc4random() %11*0.1;            // random blue indocator
        
        CGContextSetLineWidth(context1, 3);     //
        CGContextAddRect(context1, rects[i]);   // Adds black Frame
        CGContextStrokePath(context1);          //

     
  
        CGAffineTransform fliptrasform = CGAffineTransformMakeRotation(M_PI/2.20);                  //
        CGContextSelectFont(context1, "Helvetica-Bold", 8, kCGEncodingMacRoman);                    //
        CGContextSetCharacterSpacing(context1, kCGTextFillStroke);                                  // Adds
        CGContextSetTextMatrix(context1, fliptrasform);                                             // black
        CGContextSetRGBFillColor(context1, 0, 0, 0, 1);                                             // string
        cStringName = [@"%@",[[self.placesToDraw objectAtIndex:i] name] UTF8String];                // on top
        CGContextShowTextAtPoint(context1,rects[i].origin.x+20,315 ,                                //
                                 cStringName,[[self.placesToDraw objectAtIndex:i] name].length);    //
        
        fliptrasform = CGAffineTransformMakeRotation(0);                                                    //
        CGContextSetTextMatrix(context1, fliptrasform);                                                     //
        CGContextSelectFont(context1, "Helvetica-Bold", 10, kCGEncodingMacRoman);                           // Adds
        costValue = [[NSString alloc] initWithFormat:@"%f",[[self.placesToDraw objectAtIndex:i] cost]];     // black
        cStringCost = [@"%@",costValue UTF8String];                                                         // string
        CGContextShowTextAtPoint(context1, rects[i].origin.x+3, rects[i].origin.y+3 ,                       // at the bottom
                                 cStringCost,5);                                                            //
        
        
    }

    CGColorSpaceRelease(colorspaceNet);                                 // release
    CGColorRelease(colorNet);                                           // the color for the net

    CGColorSpaceRelease(colorspace);                                    // release
    CGColorRelease(color);                                              // the color
    

}



    

    


@end
