//
//  AddViewController.m
//  iTravel
//
//  Created by Student05 on 2/4/13.
//  Copyright (c) 2013 Student05. All rights reserved.
//

#import "AddViewController.h"
#import "Social/Social.h"
#import "ListTableViewController.h"
#import "AppDelegate.h"
#import "Place.h"


@interface AddViewController (){
    SLComposeViewController *slComposeViewController;
    NSDictionary  *locationDict;
    __block NSMutableString *locateAt;
}

@end

@implementation AddViewController
@synthesize textView = _textView;
@synthesize photoImageView = _photoImageView;
@synthesize chosenImage = _chosenImage;
@synthesize imagePicker = _imagePicker;
@synthesize placeNametextField = _placeNametextField;
@synthesize friendsTextField = _friendsTextField;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    self.title = @"Add Places";
    self.photoImageView.image = [UIImage imageNamed:@"noPhoto.jpeg"];
    [super viewDidLoad];
    slComposeViewController = [[SLComposeViewController alloc] init];
    
    locationDict = [[NSDictionary alloc] init];
    
    locateAt = [[NSMutableString alloc] init];
    
    locationManager = [[CLLocationManager alloc] init];
    locationManager.desiredAccuracy=kCLLocationAccuracyNearestTenMeters;
    locationManager.distanceFilter=10;
    locationManager.delegate=self;
    [locationManager startUpdatingLocation];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)addPlace:(id)sender {
    UIAlertView *allert = [[UIAlertView alloc] initWithTitle:@"Adding Place in Your Phone" message:@"Would you like to share the information to social network" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Facebook",@"Twitter", nil];
    [allert show];

}

- (IBAction)addPhotoFromGallery:(id)sender {
    
    self.imagePicker = [[UIImagePickerController alloc] init];
    self.imagePicker.delegate=self;
    [self.imagePicker setSourceType:UIImagePickerControllerSourceTypePhotoLibrary];
    [self presentViewController:self.imagePicker animated:YES completion:nil];
}
-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info{
    self.chosenImage = info[UIImagePickerControllerOriginalImage];
    [self.photoImageView setImage:self.chosenImage];
    [self dismissViewControllerAnimated:YES completion:nil];
}
-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker{
    [self dismissViewControllerAnimated:YES completion:nil];
}
- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text {
    
    if([text isEqualToString:@"\n"]) {
        [textView resignFirstResponder];
        return NO;
    }
    
    return YES;
}
-(BOOL) textFieldShouldReturn:(UITextField*) textField {
    [textField resignFirstResponder];
    return YES;
}
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if(buttonIndex == 0 )
    {
        //saves the data
        //here
    }
    else if (buttonIndex == 1)
    {
        if([SLComposeViewController isAvailableForServiceType:SLServiceTypeFacebook])
           {
               slComposeViewController = [SLComposeViewController composeViewControllerForServiceType:SLServiceTypeFacebook];
               [slComposeViewController setInitialText:self.textView.text];
               [slComposeViewController addImage:self.chosenImage];
               [self presentViewController:slComposeViewController animated:YES completion:nil];
           }
      
        
    }else if (buttonIndex == 2)
    {
        if([SLComposeViewController isAvailableForServiceType:SLServiceTypeTwitter])
        {
            slComposeViewController = [SLComposeViewController composeViewControllerForServiceType:SLServiceTypeTwitter];
            [slComposeViewController setInitialText:self.textView.text];
            [slComposeViewController addImage:self.chosenImage];
            [self presentViewController:slComposeViewController animated:YES completion:nil];
            
        }
       
    }
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([segue.identifier isEqualToString: @"pickLocation"]) {
       LocationPickerViewController *locationPickerVC = segue.destinationViewController;
        [locationPickerVC setDelegate:self];
    }
   
}


- (IBAction)locationButton:(id)sender {
   // UIActionSheet *locationPickActionSheet = [[UIActionSheet alloc] initWithTitle:@"Pick Location" delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil otherButtonTitles:@"Current Location", @"Point on Map",@"Cancel" nil];
    UIActionSheet *locationPickActionSheet = [[UIActionSheet alloc] initWithTitle:@"Pick Location" delegate:self cancelButtonTitle:nil destructiveButtonTitle:nil otherButtonTitles:@"Current Location", @"Point on Map",@"Cancel", nil];
    [locationPickActionSheet showInView:self.view];
}

- (IBAction)savePlace:(id)sender {
    AppDelegate* delegate = (AppDelegate*) [UIApplication sharedApplication].delegate;
    NSManagedObjectContext *moc = [delegate managedObjectContext];
    
    Place *newEntry = (Place*)[NSEntityDescription insertNewObjectForEntityForName:@"Place"
                                                                  inManagedObjectContext:moc];
    
    newEntry.name = self.placeNametextField.text;
    newEntry.image = UIImagePNGRepresentation(self.photoImageView.image);
    newEntry.price = [NSNumber numberWithDouble:[self.priceTextField.text doubleValue]];
    newEntry.date = [NSDate date];
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"yyyyMMddhhmmsss"];
    
    NSDate* now = [NSDate date];
    NSString* notesFineName = [NSString stringWithFormat: @"%@%@", [formatter stringFromDate:now], @".txt"];
    
    NSString* documentsDir = [[delegate applicationDocumentsDirectory] path];
    NSString *path = [documentsDir stringByAppendingPathComponent: notesFineName];
    
    newEntry.notesFile = path;
    
    NSString* notes = self.textView.text;
    [notes writeToFile:path atomically:YES encoding:NSUTF8StringEncoding error:nil];
    
    newEntry.lat = [locationDict objectForKey:@"lat"];
    newEntry.lon = [locationDict objectForKey:@"lon"];
    
    NSLog(@" lat:%@ lon::%@",[newEntry.lat stringValue],[newEntry.lon stringValue]);
    
    NSLog(@"Save addres");
    newEntry.address = [locateAt copy];
    
    NSError* error;
    [moc save:&error];
    
    [self.navigationController popViewControllerAnimated:YES];
    
}

-(void)reverseGeocodeLocation:(CLLocation *)location{
    CLGeocoder *geoCoder = [[CLGeocoder alloc] init];
    [geoCoder reverseGeocodeLocation:location completionHandler:^(NSArray *placemarks, NSError *error)
     {
         //get the nearby address
         CLPlacemark *placemark = [placemarks objectAtIndex:0];
         
         //String to holdthe address
         locateAt = [[placemark.addressDictionary valueForKey:@"FormattedAddressLines"] componentsJoinedByString:@", "];
         
         NSLog(@"Location Address: %@",locateAt);
     }];
    
}


#pragma mark - Action Sheet Delegate

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (buttonIndex == actionSheet.cancelButtonIndex) {
        [actionSheet dismissWithClickedButtonIndex:-1 animated:YES];
    }else if(buttonIndex == 0){
        //Current Location
        NSLog(@"Current Location");
        NSNumber *latitude = [NSNumber numberWithDouble:locationManager.location.coordinate.latitude];
        NSNumber *longitude = [NSNumber numberWithDouble:locationManager.location.coordinate.longitude];
        
        locationDict = [NSDictionary dictionaryWithObjects:@[latitude, longitude] forKeys:@[@"lat",@"lon"]];
        
       // [placeInfoDict setObject:locationDict forKey:PLACE_LOCATION];
        [self.navigationController popViewControllerAnimated:YES];
        
    }else if(buttonIndex == 1){
        //Pick on Map
        NSLog(@"Pick on Map");
        //LocationPickerViewController *locationPickerVC = [[LocationPickerViewController alloc] init];
        //[locationPickerVC setDelegate:self];
        //[self.navigationController pushViewController:locationPickerVC animated:YES];
    }
    else{
        NSLog(@"Cancel");
        [self.navigationController popViewControllerAnimated:YES];
    }
}

#pragma mark - Location Editing

- (void)setLocationDict:(NSDictionary *)newLocationDict{
    locationDict = newLocationDict;
    CLLocation * locationCoord = [[CLLocation alloc] initWithLatitude:[[locationDict objectForKey:@"lat"] doubleValue] longitude:[[locationDict objectForKey:@"lon"] doubleValue]];
    [self reverseGeocodeLocation:locationCoord];
}


-(void)keyboardDidShow:(NSNotification *)notification{
    if ([[UIScreen mainScreen] bounds].size.height == 568) {
        [self.view setFrame:CGRectMake(0, -100, 320, 568)]; //if iphone 5
    } else {
        [self.view setFrame:CGRectMake(0, -100, 320, 504)]; //if iphone 3g 4 4s
    }
}
-(void)keyboardDidHide:(NSNotification *)notification{
    if ([[UIScreen mainScreen] bounds].size.height == 568) {
        [self.view setFrame:CGRectMake(0, 0, 320, 568)]; //if iphone 5
    } else {
        [self.view setFrame:CGRectMake(0, 0, 320, 504)]; //if iphone 3g 4 4s
    }
}




@end
