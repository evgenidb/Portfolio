//
//  DetailInfoVIewControllerViewController.h
//  iTravel
//
//  Created by Student05 on 2/7/13.
//  Copyright (c) 2013 Student05. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailInfoVIewControllerViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIImageView *pictureImageView;
@property (weak, nonatomic) IBOutlet UILabel *namePlaceLabel;
@property (weak, nonatomic) IBOutlet UILabel *addressPlaceLabel;
@property (weak, nonatomic) IBOutlet UILabel *additionalTextLabel;
@property (weak, nonatomic) IBOutlet UILabel *costLabel;

@property NSString *name;
@property NSString *notes;
@property UIImage *image;
@property NSString *price;
@property NSString  *address;



@end
