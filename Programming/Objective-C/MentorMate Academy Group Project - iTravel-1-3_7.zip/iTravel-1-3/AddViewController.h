//
//  AddViewController.h
//  iTravel
//
//  Created by Student05 on 2/4/13.
//  Copyright (c) 2013 Student05. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LocationPickerViewController.h"

@interface AddViewController : UIViewController <UIImagePickerControllerDelegate,UINavigationControllerDelegate,UITextViewDelegate,UITextFieldDelegate,UIAlertViewDelegate, UIActionSheetDelegate, CLLocationManagerDelegate, LocationEditing>{
    
    CLLocationManager *locationManager;
}


- (IBAction)addPlace:(id)sender;
- (IBAction)addPhotoFromGallery:(id)sender;
@property (weak, nonatomic) IBOutlet UITextField *placeNametextField;
@property (weak, nonatomic) IBOutlet UITextField *friendsTextField;


@property (weak, nonatomic) IBOutlet UIImageView *photoImageView;
@property (nonatomic,strong) UIImage *chosenImage;
@property (nonatomic,strong) UIImagePickerController *imagePicker;
@property (weak, nonatomic) IBOutlet UITextView *textView;

@property (weak, nonatomic) IBOutlet UITextField *priceTextField;
- (IBAction)locationButton:(id)sender;

- (IBAction)savePlace:(id)sender;

@end
