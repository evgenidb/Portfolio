//
//  ListTableViewController.h
//  iTravel
//
//  Created by Student05 on 2/4/13.
//  Copyright (c) 2013 Student05. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>

@interface ListTableViewController : UITableViewController <UITableViewDataSource, UITableViewDelegate, NSFetchedResultsControllerDelegate>

@property (strong, nonatomic) IBOutlet UITableView *placesTableView;
@property (nonatomic, strong) NSFetchedResultsController* resultsController;

@property (nonatomic,strong) NSMutableArray *places;

@end
