//
//  PlaceAnnotation.m
//  iTravel
//
//  Created by Student05 on 2/8/13.
//  Copyright (c) 2013 Student05. All rights reserved.
//

#import "PlaceAnnotation.h"

@interface PlaceAnnotation ()

// Make the properties readwrite, so we can init/change them within the class
// Properties
@property (nonatomic, readwrite) NSString *placeName;
@property (nonatomic, readwrite) NSString *placeAddress;
@property (nonatomic, readwrite) CLLocationCoordinate2D placeCoordinate;
@property (nonatomic, readwrite) int annotationTag;

@end



@implementation PlaceAnnotation

- (id)initWithName:(NSString*)name
           address:(NSString*)address
        coordinate:(CLLocationCoordinate2D)coordinate
{
    self = [super init];
    
    if (self) {
        /*
        self.placeName = [name copy];
        self.placeAddress = [address copy];
        */
        self.placeName = name;
        self.placeAddress = address;
        
        self.placeCoordinate = coordinate;
    }
    return self;
}

- (NSString *)title{
    return self.placeName;
}

- (NSString *)subtitle{
    return self.placeAddress;
}

- (CLLocationCoordinate2D)coordinate{
    return self.placeCoordinate;
}

@end
