//
//  LocationPickerViewController.h
//  iTravel
//
//  Created by Student05 on 2/8/13.
//  Copyright (c) 2013 Student05. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import "PlaceAnnotation.h"

@protocol LocationEditing
- (void)setLocationDict:(NSDictionary *)newLocationDict;
@end

@interface LocationPickerViewController : UIViewController

@property (weak, nonatomic) IBOutlet MKMapView *mapView;
@property (nonatomic, strong) PlaceAnnotation *selectedLocationAnnotation;
@property (nonatomic, weak) id <LocationEditing>  delegate;

@end
