//
//  PlaceAnnotation.h
//  iTravel
//
//  Created by Student05 on 2/8/13.
//  Copyright (c) 2013 Student05. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <MapKit/MapKit.h>

@interface PlaceAnnotation : NSObject<MKAnnotation>

/*
// You don't need strong, assign, copy, etc. You need them only when you're doing Manual Reference Counting, .i.e. when you're the one taking care of the memory
@property (nonatomic, strong) NSString *placeName;
@property (nonatomic, strong) NSString *placeAddress;
@property (nonatomic, assign) CLLocationCoordinate2D placeCoordinate;
@property (nonatomic, assign) int annotationTag;
*/


// Also, in this case you want the properties readonly,
// so that noone will accidently (or not) change them.
// You need to init the properties just once - when you init them.
@property (nonatomic, readonly) NSString *placeName;
@property (nonatomic, readonly) NSString *placeAddress;
@property (nonatomic, readonly) CLLocationCoordinate2D placeCoordinate;


// Also, for what do you need this for? It's not used in the class at all!
@property (nonatomic, readonly) int annotationTag;


// Methods
- (id)initWithName:(NSString*)name
           address:(NSString*)address
        coordinate:(CLLocationCoordinate2D)coordinate;

@end
