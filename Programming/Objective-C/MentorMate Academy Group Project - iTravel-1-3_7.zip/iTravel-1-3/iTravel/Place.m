//
//  Place.m
//  iTravel
//
//  Created by Student05 on 2/8/13.
//  Copyright (c) 2013 Student05. All rights reserved.
//

#import "Place.h"
#import "Friend.h"


@implementation Place

@dynamic name;
@dynamic image;
@dynamic notesFile;
@dynamic price;
@dynamic lat;
@dynamic lon;
@dynamic address;
@dynamic date;
@dynamic friends;

@end
