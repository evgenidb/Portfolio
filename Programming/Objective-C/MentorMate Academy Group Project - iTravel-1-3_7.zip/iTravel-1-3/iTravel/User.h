//
//  User.h
//  iTravel
//
//  Created by Student05 on 2/8/13.
//  Copyright (c) 2013 Student05. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class Place;

@interface User : NSManagedObject

@property (nonatomic, retain) NSString * name;
@property (nonatomic, retain) NSString * facebook_id;
@property (nonatomic, retain) NSNumber * score;
@property (nonatomic, retain) NSString * status;
@property (nonatomic, retain) NSSet *places;
@end

@interface User (CoreDataGeneratedAccessors)

- (void)addPlacesObject:(Place *)value;
- (void)removePlacesObject:(Place *)value;
- (void)addPlaces:(NSSet *)values;
- (void)removePlaces:(NSSet *)values;

@end
