//
//  LocationPickerViewController.m
//  iTravel
//
//  Created by Student05 on 2/8/13.
//  Copyright (c) 2013 Student05. All rights reserved.
//

#import "LocationPickerViewController.h"

@interface LocationPickerViewController ()

@end

@implementation LocationPickerViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    self.title = @"Pick Location";
    
    //Center the map on Sofia
    CLLocationCoordinate2D centerCoordinate;  //OR GET User current location cordinates
    centerCoordinate.latitude = 42.685685;
    centerCoordinate.longitude = 23.319125;
    MKCoordinateRegion viewRegion = MKCoordinateRegionMakeWithDistance(centerCoordinate, 5000.0, 5000.0);
    MKCoordinateRegion adjustedRegion = [self.mapView regionThatFits:viewRegion];
    [self.mapView setRegion:adjustedRegion animated:YES];
    
    UIBarButtonItem *saveButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemSave target:self action:@selector(save)];
    [saveButton setEnabled:NO];
	self.navigationItem.rightBarButtonItem = saveButton;
	
	UIBarButtonItem *cancelButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemCancel target:self action:@selector(cancel)];
	self.navigationItem.leftBarButtonItem = cancelButton;
    
    UILongPressGestureRecognizer *lpgr = [[UILongPressGestureRecognizer alloc]
                                          initWithTarget:self action:@selector(handleLongPress:)];
    lpgr.minimumPressDuration = 1.0;
    [self.mapView addGestureRecognizer:lpgr];
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)handleLongPress:(UIGestureRecognizer *)gestureRecognizer{
    if (gestureRecognizer.state == UIGestureRecognizerStateBegan){
        //Enable the SAVE button
        [self.navigationItem.rightBarButtonItem setEnabled:YES];
        CGPoint touchPoint = [gestureRecognizer locationInView:self.mapView];
        CLLocationCoordinate2D touchMapCoordinate = [self.mapView convertPoint:touchPoint toCoordinateFromView:self.mapView];
        
        if(self.selectedLocationAnnotation){
            [self.mapView removeAnnotation:self.selectedLocationAnnotation];
        }
        
        
        /*
        // Why are you using the init method instead of initWithName:address:coordinate?
        
        self.selectedLocationAnnotation = [[PlaceAnnotation alloc] init];
        self.selectedLocationAnnotation.placeCoordinate = touchMapCoordinate;
        */
        
        self.selectedLocationAnnotation = [[PlaceAnnotation alloc] initWithName:@"" address:@"" coordinate:touchMapCoordinate];
        
        [self.mapView addAnnotation:self.selectedLocationAnnotation];
    }
}

- (void)save {
    // Pass the current value to the delegate, then pop.
    NSNumber *latitude = [NSNumber numberWithDouble:self.selectedLocationAnnotation.placeCoordinate.latitude];
    NSNumber *longitude = [NSNumber numberWithDouble:self.selectedLocationAnnotation.placeCoordinate.longitude];
    NSDictionary *locationDict = [NSDictionary dictionaryWithObjects:@[latitude, longitude] forKeys:@[@"lat",@"lon"]];
    [self.delegate setLocationDict:locationDict];
    
    [self.navigationController popViewControllerAnimated:YES];
}


- (void)cancel {
    // Don't pass the current value to the edited object, just pop.
    [self.navigationController popViewControllerAnimated:YES];
}

@end
