//
//  User.m
//  iTravel
//
//  Created by Student05 on 2/8/13.
//  Copyright (c) 2013 Student05. All rights reserved.
//

#import "User.h"
#import "Place.h"


@implementation User

@dynamic name;
@dynamic facebook_id;
@dynamic score;
@dynamic status;
@dynamic places;

@end
