//
//  ChartView.h
//  iTravel
//
//  Created by Student05 on 2/5/13.
//  Copyright (c) 2013 Student05. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ChartView : UIView

@property (nonatomic) NSMutableArray *placesToDraw;



-(id)initWithFrame:(CGRect)frame andPlaces:(NSMutableArray *)places;

@end
