//
//  Location.m
//  iTravel
//
//  Created by Student08 on 2/8/13.
//  Copyright (c) 2013 Student05. All rights reserved.
//

#import "Location.h"

@interface Location()


// Properties
// ID - also used for hashing
@property (nonatomic, readwrite) NSString* locationID;

// Location Properties
@property (nonatomic, readwrite) NSString* name;
@property (nonatomic, readwrite) NSString* address;
@property (nonatomic, readwrite) CLLocationCoordinate2D coordinate;
@property (nonatomic, readwrite) NSString* iconPath;
@property (nonatomic, readwrite) NSSet* types;

// Deprecated properties
// @property (nonatomic, readwrite) NSString* imagePath;

@end



@implementation Location



// Methods
// Inits
-(id)initLocationWithDict:(NSDictionary*)locationDictionary
{
    self = [super init];
    
    if (self && [self isLocationValid:locationDictionary])
    {
        self.locationID = locationDictionary[@"locationID"];
        
        self.name = locationDictionary[@"name"];
        
        self.address = locationDictionary[@"address"];
        
        self.coordinate = CLLocationCoordinate2DMake([locationDictionary[@"coordinate"][@"lat"] doubleValue], [locationDictionary[@"coordinate"][@"lng"] doubleValue]);
        
        // self.imagePath = locationDictionary[@"imagePath"];
        
        self.iconPath = locationDictionary[@"iconPath"];
        
        self.types = locationDictionary[@"types"];
        
        [self hash];
        
    }
    
    return self;
}

// Update the location data with Dict
-(void)updateLocationWithDict:(NSDictionary*)locationDictionary
{
    // Can't update the Location and ID, though: they must be initialized in the very begining!
    
    if (locationDictionary[@"name"] != nil) {
        self.name = locationDictionary[@"name"];
    }
    
    if (locationDictionary[@"address"] != nil) {
        self.address = locationDictionary[@"address"];
    }
    
    /*
    if (locationDictionary[@"imagePath"] != nil) {
        self.imagePath = locationDictionary[@"imagePath"];
    }
    */
    
    if (locationDictionary[@"iconPath"] != nil) {
        self.iconPath = locationDictionary[@"iconPath"];
    }
    
    if (locationDictionary[@"types"] != nil) {
        self.types = locationDictionary[@"types"];
    }
}




// Check for equal addressess
-(BOOL)isEqual:(Location *)otherLocation
{
    if ([self.locationID isEqualToString:otherLocation.locationID])
    {
        return YES;
    }
    else
    {
        return NO;
    }
}

-(NSUInteger)hash
{
    return [self.locationID hash];
}


// Checks
-(BOOL) isLocationValid:(NSDictionary*)locationDict
{
    NSArray* arrayLocationKeys = locationDict.allKeys;
    
    BOOL hasLocID = [arrayLocationKeys containsObject:@"locationID"];
    BOOL hasCoordinate = [arrayLocationKeys containsObject:@"coordinate"];
    NSArray* locCoordinates = [locationDict[@"coordinate"] allKeys];
    BOOL hasCoordinateLatitude = [locCoordinates containsObject:@"lat"];
    BOOL hasCoordinateLongitude = [locCoordinates containsObject:@"lng"];
    
    if (hasLocID && hasCoordinate && hasCoordinateLatitude && hasCoordinateLongitude) {
        return YES;
    }
    else
    {
        return NO;
    }
}

-(BOOL) isLocationOfType:(NSString*)type
{
    for (NSString* locationTypes in self.types) {
        if ([locationTypes isEqualToString:type]) {
            return YES;
        }
    }
    
    return NO;
}


@end
