//
//  SettingsViewController.m
//  iTravel
//
//  Created by Student05 on 2/4/13.
//  Copyright (c) 2013 Student05. All rights reserved.
//

#import "SettingsViewController.h"
#import "AppDelegate.h"
#import "Place.h"

@interface SettingsViewController ()

@end

@implementation SettingsViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.title = @"Settings";
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
   
    // Dispose of any resources that can be recreated.
}

- (IBAction)deletaAllPlaces:(id)sender {
    AppDelegate* delegate = (AppDelegate*) [UIApplication sharedApplication].delegate;
	NSManagedObjectContext *moc = [delegate managedObjectContext];
	NSEntityDescription *entityDescription = [NSEntityDescription entityForName:@"Place" inManagedObjectContext:moc];
    NSSortDescriptor *sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:@"date" ascending:YES];
	NSFetchRequest *request = [[NSFetchRequest alloc] init];
	[request setEntity:entityDescription];
    [request setSortDescriptors:[NSArray arrayWithObject:sortDescriptor]];
    
    NSError *error;  //TODO handle error
    NSArray * fetchedPlaces =[moc executeFetchRequest:request error:&error];
    
    for (Place *place in fetchedPlaces) {
        //delete file
        [[NSFileManager defaultManager] removeItemAtPath:place.notesFile error:nil];
 
        //delete object
        [moc deleteObject:place];
    }
    
    NSError *deleteError;
    if(![moc save:&error])
    {
        NSLog(@"error in deleting all objects:%@",[deleteError localizedDescription]);
    }
    NSLog(@"DONE DELETING ALL");
}
@end
