//
//  LocationContainer.h
//  iTravel
//
//  Created by Student08 on 2/8/13.
//  Copyright (c) 2013 Student05. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Location.h"

@interface LocationContainer : NSObject
// Properties
@property (nonatomic, readonly) NSMutableSet* locations;

// Methods
// For singleton
+(LocationContainer*) sharedLocationContainer;

// Add/Remove Hotels
-(void) addLocation:(Location *)locationToAdd;
-(void) removeLocation:(Location *)locationToRemove;
-(void) removeAllLocations;


// Getters
-(NSSet *) getLocationsOfType:(NSString *)type;


// Counting


@end
