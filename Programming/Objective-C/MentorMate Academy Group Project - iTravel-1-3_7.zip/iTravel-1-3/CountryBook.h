//
//  CountryBook.h
//  iTravel
//
//  Created by Student05 on 2/4/13.
//  Copyright (c) 2013 Student05. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Country.h"
#import "GameViewController.h"

@interface CountryBook : NSObject

+sharedInstance;

-(id)init;
-(int)numberOfCountries;
-(Country *)countryAtIndex:(NSUInteger)index;
-(Country *)countryatRandomIndex;


@end
