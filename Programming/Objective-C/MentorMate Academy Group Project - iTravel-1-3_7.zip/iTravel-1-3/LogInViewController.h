//
//  LogInViewController.h
//  iTravel
//
//  Created by Student05 on 2/4/13.
//  Copyright (c) 2013 Student05. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>
#import "Social/Social.h"

@interface LogInViewController : UIViewController <NSFetchedResultsControllerDelegate , UIAlertViewDelegate>{

    SLComposeViewController *slComposeViewController;
}

@property (strong, nonatomic) NSFetchedResultsController *fetchedResultsController;
@property (strong, nonatomic) NSManagedObjectContext *managedObjectContext;




@end
