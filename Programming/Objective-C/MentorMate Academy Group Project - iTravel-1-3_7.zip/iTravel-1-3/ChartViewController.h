//
//  ChartViewController.h
//  iTravel
//
//  Created by Student05 on 2/4/13.
//  Copyright (c) 2013 Student05. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ChartView.h"

@interface ChartViewController : UIViewController <NSFetchedResultsControllerDelegate>
@property (nonatomic,strong) NSMutableArray *places;
@property (weak, nonatomic) IBOutlet UIScrollView *chartScroolView;
@property (nonatomic) CGFloat width;





@end
