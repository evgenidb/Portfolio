//
//  TemporaryChart.m
//  iTravel
//
//  Created by Student05 on 2/5/13.
//  Copyright (c) 2013 Student05. All rights reserved.
//

#import "TemporaryChart.h"

@implementation TemporaryChart
@synthesize name=_name;
@synthesize cost=_cost;
-(id)initWithCost:(float)number{

    return [self initWithCost:50.0 andName:@"Place's Name"];
}

-(id)initWithCost:(float)number andName:(NSString *)name{
    self = [super init];
    if(self){
        _cost=number;
        _name=name;
    }
    return self;
}
-(id)init{
    return [self initWithCost:50.0];
}

@end
