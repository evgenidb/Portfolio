//
//  Location.h
//  iTravel
//
//  Created by Student08 on 2/8/13.
//  Copyright (c) 2013 Student05. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <MapKit/MapKit.h>

@interface Location : NSObject


// Properties
// Location ID - used for hashing
@property (nonatomic, readonly) NSString* locationID;

// Location Properties
@property (nonatomic, readonly) NSString* name;
@property (nonatomic, readonly) CLLocationCoordinate2D coordinate;
@property (nonatomic, readonly) NSString* address;
@property (nonatomic, readonly) NSString* iconPath;
@property (nonatomic, readonly) NSSet* types;

// Deprecated properties
// @property (nonatomic, readonly) NSString* imagePath;


// Methods
// Inits
-(id)initLocationWithDict:(NSDictionary*)locationDictionary;

// Update Location
-(void)updateLocationWithDict:(NSDictionary*)locationDictionary;


// Checks
-(BOOL) isLocationOfType:(NSString*)type;

@end
